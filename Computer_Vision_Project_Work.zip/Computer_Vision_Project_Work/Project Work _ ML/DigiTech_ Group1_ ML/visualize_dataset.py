import numpy as np
import pandas as pd
from PIL import Image
import matplotlib.pyplot as plt

def visualize_dataset(train_data):
    X_train_image = train_data.loc[:, train_data.columns != 'label'].values
    train_ar = np.empty((28, 28, len(train_data)))

    for m in range(len(train_data)):  # digit
        for i in range(28):  # rows
            for j in range(28):  # columns
                train_ar[i][j][m] = X_train_image[m, i * 28 + j]

    img_train_digits = np.empty((28, 5628))
    col = np.empty((28, 28))
    row_cnt = 0
    px_cnt = 0
    for m in range(len(train_data)):
        px_cnt += 1
        col = np.hstack((col, train_ar[:, :, m]))  # putting 200 digits one after the other, from the left to the right
        if px_cnt % 200 == 0:  # now I have a row of 200 digits, so I'm going to stack a row on top of the other
            if row_cnt == 0:
                img_train_digits = col
            else:
                img_train_digits = np.vstack((img_train_digits, col))  # stacking rows of 200 digits until I run out of digits
            row_cnt += 1
            col = np.empty((28, 28))  # this is the first element of each row, I made it so I have something to start making each row. Feeling cute now, might delete late
    img_train_digits = img_train_digits[:, 29:]  # ...deleted
    gr_im = Image.fromarray(img_train_digits)
    plt.figure(figsize=(20, 21))
    plt.imshow(gr_im)
