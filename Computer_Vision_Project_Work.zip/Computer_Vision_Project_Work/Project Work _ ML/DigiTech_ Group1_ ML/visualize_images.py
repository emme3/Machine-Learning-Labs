import numpy as np
import matplotlib.pyplot as plt

def visualize_images(dataset, rows, cols):
    # Convert dataset to a numpy array reshaping the data
    dataset_array = dataset.values.reshape(-1, 28, 28)
    
    # Create a plot with specified rows and columns
    f, ax = plt.subplots(rows, cols)
    f.set_size_inches(10, 10)
    
    k = 0
    for i in range(rows):
        for j in range(cols):
            ax[i, j].imshow(dataset_array[k], cmap="gray")
            k += 1
            
    plt.tight_layout()
    plt.show()


